#include <iostream>
#include <cmath>

using namespace std;

int main() {
  int cm=0, ft=0;
  double inch;

  cin >> cm;

  inch = cm / 2.54;

  ft = inch / 12;
    inch = (cm - ft * 2.54 * 12)/2.54;

  cout << floor(ft) << " ft " << floor(inch) << " in";

  return 0;

}
#include <iostream>

int is_leap_year(int year);
int get_days_of_month(int year, int month);
int check_date(int year, int month, int day);

int main(void) {
	int year, month, day;
	do{
		std::cin >> year >> month >> day;
		if(!check_date(year, month, day)){
			std::cout << "ERROR" << std::endl;
		} else {
			std::cout << year << "년 " << month << "월 " << day << "일" << std::endl;
			return 0;
		}
	}while(1);
	return 0;
}
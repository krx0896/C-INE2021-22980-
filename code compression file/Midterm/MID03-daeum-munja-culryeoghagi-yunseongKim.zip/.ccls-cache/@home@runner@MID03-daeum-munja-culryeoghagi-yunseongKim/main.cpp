#include <iostream>
#include <string>
using namespace std;

int main() {
 char a;
 cin >> a;


 if(a == 122){
   cout << char(97);
 } else { cout << char(a + 1) << endl;}
 
 return 0;
}
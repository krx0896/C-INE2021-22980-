#include <iostream>
#include <iomanip>
#define STUDENT_MAX 10
#define NUM_OF_SUBJECTS 3
#define HEADER "KOR  ENG  MAT  TOT  AVG"

void input(double scores[][NUM_OF_SUBJECTS+2], int num_of_students);
void calc(double scores[][NUM_OF_SUBJECTS+2], int num_of_students);
void print(double scores[][NUM_OF_SUBJECTS+2], int num_of_students);

int main() {
	int num_of_students;
	double scores[STUDENT_MAX][NUM_OF_SUBJECTS+2];
	std::cin >> num_of_students;
	input(scores, num_of_students);
	calc(scores, num_of_students);
	print(scores, num_of_students);
} 
#include <iostream>
#include <cmath>

using namespace std;


int round_pos(int num, int pos){
  int pos10 = pow(10,-pos);

  int round1 = round(num*pos10); 
  
  int pos11 = pow(10, pos);
  int output= round1/pos11;

  return(output);
}


int main(void) {
	int num, pos;
	cin >> num >> pos;
	cout << round_pos(num, pos);
  return 0;
} 
#include <iostream>
#include <cmath>
#define OUTPUT_ERR "ERROR\n"

using namespace std;

int main() {
  int num;
  cin >> num;
  do
  {
  if(num >= 1440){
    cout << OUTPUT_ERR;
  } else if(num <= 30){
    cout << "2000";
  } else if(num > 30 && num < 1440){
    cout << 1000 * (num/3);
  }
  } while(num==0);
} 
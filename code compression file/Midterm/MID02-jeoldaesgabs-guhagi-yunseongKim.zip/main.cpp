#include <iostream>
#include <cmath>
using namespace std;

int main() {
  int a;
  cin >> a;
  cout << abs(a) << endl;

  return 0;
}  
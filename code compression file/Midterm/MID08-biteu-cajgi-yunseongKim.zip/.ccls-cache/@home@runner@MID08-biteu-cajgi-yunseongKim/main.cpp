#include <iostream>

int find1(int);

int main(void) {
	int num;
	std::cin >> num;
	std::cout << find1(num);
	return 0;
}
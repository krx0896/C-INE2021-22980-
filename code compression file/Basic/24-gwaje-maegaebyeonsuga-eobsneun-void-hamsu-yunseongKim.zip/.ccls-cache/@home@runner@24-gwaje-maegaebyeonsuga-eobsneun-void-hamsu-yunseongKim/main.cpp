#define HELLO "Hello World"
// 입출력을 위한 헤더파일을 포함시킨다.
#include <iostream>
// std namespace 사용을 선언한다.
using namespace std;
/**
* 반복문을 사용해 가로로 30개의 *을 출력하는 함수
* 출력을 마치면 줄바꿈 문자를 출력한다.
* @param void
* @return void
*/
void print_stars(){

    for(int i=1 ; i<=30 ; i++){

    cout << "*";
  }
  
  return;
}

int main(void) {
  
    print_stars();
    cout << endl << HELLO << endl;
    print_stars();

	return 0;
}
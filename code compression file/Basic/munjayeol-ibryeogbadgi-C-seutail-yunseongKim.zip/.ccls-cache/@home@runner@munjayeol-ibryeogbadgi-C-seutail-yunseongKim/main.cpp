// 입출력 함수를 위한 해더를 포함시킵니다.
#include <iostream>
// 문자열을 다루기 위한 해더를 포함시킵니다.
#include<string>
// std 네임스페이스를 생략하기 위한 문장을 작성합니다.
using namespace std;
// 메인함수를 작성합니다.
int main(){
	// 노래 제목과 가수명을 저장할 string 변수를 생성하고 값을 할당합니다.
	// 노래 제목은 butter, 가수명은 BTS로 작성해주세요.
  string song("butter"); // 생성자
  string singer("BTS");
	// 노래 제목을 출력하고 가수명을 묻습니다.
	// 예를 들어 노래 제목을 저장한 변수가 song이라면 다음과 같이 작성합니다.
  cout << song << "을 부른 가수의 이름은? " << endl;

	// 가수 이름의 첫 글자를 힌트로 줍니다.
	// 예를 들어 가수 명을 저장한 변수가 singer라면 다음과 같이 작성합니다.
  cout << "[힌트] 가수의 이름은 " << singer.front() << "로 시작합니다." << endl;

	// 정답을 묻는 문자열을 출력합니다.
  cout << "정답: ";

	// 답안을 저장할 변수를 생성합니다.
  string answer;

	// 사용자로부터 답안을 받아 변수에 값을 받습니다.
  getline(cin , answer);

	// 답안과 가수명을 비교하여 맞으면 "정답입니다.", 틀리면 "오답입니다."를 출력합니다.
	// if문을 사용해야 합니다. 같이 작성해봅시다.
  if(singer == answer) cout << "정답입니다.";
  else cout << "오답입니다.";
  return 0;
}
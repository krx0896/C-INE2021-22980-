#include <iostream>

int main() {
  
  std::cout << "*" << std::endl;
    std::cout << "**" << std::endl;
      std::cout << "***" << std::endl;
         std::cout << "****" << std::endl;
        std::cout << "*****\n";
  return 0;
} 
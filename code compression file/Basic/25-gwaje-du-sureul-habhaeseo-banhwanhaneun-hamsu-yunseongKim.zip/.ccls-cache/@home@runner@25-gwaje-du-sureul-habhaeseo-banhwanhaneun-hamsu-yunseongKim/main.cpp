#define INSTRUCTION "두 수를 입력하세요(a b): "
#define OUTPUT "두 수의 합: "
// 입출력을 위한 헤더파일을 포함시킵니다.
#include <iostream>
// std namespace 사용을 선언합니다.
using namespace std;

/**
* 인자로 받은 두 수를 더해서 반환하는 함수
* 함수의 이름은 get_sum()으로 짓는다.
* @param a 정수형 변수로서 더할 값 1
* @param b 정수형 변수로서 더할 값 2
* @return a와 b를 더한 결과를 정수형으로 반환한다.
*/

int get_sum(int a, int b){

  int sum = a + b;
 
  return(sum);
}

int main(void) {

    // 입력 안내문을 출력합니다.
    // 입력을 저장할 두 변수를 선언합니다.
    // 두 변수를 사용자로부터 입력 받습니다.
    cout << INSTRUCTION;
    int a1, b1;
    cin >> a1 >> b1;
    // 덧셈의 결과를 저장할 변수를 선언합니다.
    // 두 변수를 인자로 get_sum()함수를 호출하고, 앞서 선언한 변수에 저장합니다.
    // OUTPUT 함께 덧셈의 결과를 출력합니다.
    cout << OUTPUT << get_sum(a1, b1);
    
    return 0;
}
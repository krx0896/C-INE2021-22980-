#include <iostream>
#define INPUT1 "0 ~ 100점 사이의 점수를 입력하세요: "
#define OUTPUT1 "점수: "
#define OUTPUT2 "학점: "
using namespace std;

int main() {
  // 입력 안내문 출력
  cout << INPUT1;
  // score 변수 생성
  int score;
  cin >> score;      // 사용자로부터 값 입력 받음
  //점수 출력
  cout << OUTPUT1 << score << endl;
  //학점 문자열 출력
  cout << OUTPUT2;
  score /= 10;  // score = score / 10; 이랑 같은뜻

  switch(score){
    case 10: 
    case 9: 
      cout << 'A';
      break;
    case 8: 
      cout << 'B';
      break;
    case 7: 
      cout << 'C';
      break;
    case 6: 
      cout << 'D';
      break;
    default:
      cout << 'F';
      break;
  }
	cout << endl;
}
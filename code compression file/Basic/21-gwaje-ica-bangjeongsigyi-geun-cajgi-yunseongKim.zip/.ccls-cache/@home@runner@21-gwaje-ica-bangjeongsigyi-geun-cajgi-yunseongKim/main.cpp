#define INSTRUCTION "3개의 계수를 a, b, c 순으로 입력하세요: "
#define NO_ROOT "근이 없습니다."
// 출력을 위한 라이브러리를 불러온다.
#include <iostream>
// 수학함수를 사용하기 위한 라이브러리를 불러온다.
#include <cmath>
using namespace std;

int main(void)
{
    // 입력 안내문을 출력한다.
    cout << INSTRUCTION;
    // 계수를 저장할 변수 3개를 선언한다.
    int a, b, c;
    // 사용자로부터 정수값 3개를 받아 변수에 각각 저장한다.
    cin >> a >> b >> c;

    // 판별식을 위한 실수형 변수를 선언한다.
    double D;
    // 판별식(b^2 - 4ac) 계산한다.
    // 힌트: pow()함수 사용
    D = pow(b,2) - 4 * a * c;
    
    // 만일 판별식의 값이 0보다 작다면
    if(D < 0){
        // 근이 없다고 출력한다.
        cout << NO_ROOT; }
    // 만일 판별식의 값이 0이라면
    else if(D == 0) {
        // 중근을 가지므로 "x1 = x2 = " 뒤에 하나의 근을 써준다.
        cout << "x1 = x2 = " << (-b + sqrt(D)) / (2 * a) << endl;
    }
    // 둘다 아니라면
    else{ 
        // "x1 = " 뒤에 첫 번째 근을 출력하고 endl을 출력한다.
        cout << "x1 = " << (-b + sqrt(D)) / (2 * a) << endl;
        // "x2 = " 뒤에 두 번째 근을 출력하고 endl을 출력한다.
        cout << "x2 = " << (-b - sqrt(D)) / (2 * a) << endl;
    }
    

    return 0; 
} 

#include <iostream>
#define INPUT "출력할 정수를 입력하세요: "
using namespace std;

int main() {

  int input;
  cout << INPUT;
  cin >> input;

  for(int counter = 0; counter < input; counter++){
    cout << counter << endl;
  }

  /*
    for(int counter = -1; counter < input;){
    counter++;
    cout << counter << endl;
  }
  */

  /*
  int counter = -1;
  for(;;){
    if(counter)
  }
  */
  return 0;
} 
#define INSTRUCTION "1~15 사이의 정수를 입력하세요: "
#define SMALL_NUM "더 작은 숫자입니다."
#define BIG_NUM "더 큰 숫자입니다."
#define SUCCESS "성공"
#define FAIL "실패.. 답 = "
// 입출력 함수를 사용하기 위한 헤더 파일을 포함시킨다.
#include <iostream>
// 랜덤 함수를 사용하기 위한 헤더 파일을 포함시킨다.
#include <cstdlib>
// 시간 함수를 사용하기 위한 헤더 파일을 포함시킨다.
#include <ctime>
// std namespace를 사용한다고 선언한다.
using namespace std;

int main () {
    
    // 하한값을 저장할 변수를 선언하고 1로 초기화한다.
    int low = 1;
    // 상한값을 저장할 변수를 선언하고 15로 초기화한다.
    int high = 15;
    // 재시도 횟수를 저장할 변수를 선언하고 5로 초기화한다.
    int tryLimit = 5;

    // srand와 time(0)를 이용해 랜덤 숫자를 초기화 한다.
    srand(time(0));
    // 랜덤 숫자를 저장할 변수를 선언하고, rand()로 랜덤 숫자를 생성해 저장한다.
    int num = rand();
    // 랜덤 숫자가 상한값과 하한값 사이의 값이 되도록 조절한다.
    num = num % (high - low + 1) + low;
    
    // 시도 횟수를 세기 위한 카운터 변수를 생성하고 0으로 초기화 한다.
    int counter = 0;
    // 정답 여부를 관리할 부울타입 변수를 생성하고 false로 초기화 한다.
    bool found = false; // f = 0 t = 1 bool함수는 두가지 값만 가진다
    // 반복문 시작
    // 시도 횟수 변수가 재시도 횟수 변수보다 작고, 맞추지 못한 동안 반복한다.
    while (counter < tryLimit && !found) {
        // 입력 안내문을 출력한다.
        cout << INSTRUCTION;
        // 사용자의 입력을 저장할 변수를 선언한다.
        int guess;
        // 사용자로부터 값을 입력받아 변수에 저장한다.
        cin >> guess;

        // 만일 사용자의 입력이 랜덤 숫자와 같다면
        if (guess == num) {
            // 정답 여부 관리 변수를 true로 변경한다.
          found = true;
        // 만일 사용자의 입력이 랜덤 숫자보다 크다면
        } else if (guess > num){
            // SMALL_NUM을 출력한다.
          cout << SMALL_NUM << endl;
        // 그 외의 경우
        } else {
            // BIG_NUM을 출력한다.
        cout << BIG_NUM << endl;
        }
        // 시도 횟수 변수를 하나 증가시킨다.
        counter++;

    }
    // 추측에 성공한 경우 (= 정답 여부 관리 변수가 true인 경우)
    if (found) {
        // SUCCESS를 출력하고, 뒤에 endl을 출력한다.
      cout << SUCCESS << endl;

    // 추측에 실패한 경우
    } else {
        // FAIL을 출력하고, 뒤에 정답과 endl을 출력한다.
      cout << FAIL << num << endl;
    }
    return 0; 
}

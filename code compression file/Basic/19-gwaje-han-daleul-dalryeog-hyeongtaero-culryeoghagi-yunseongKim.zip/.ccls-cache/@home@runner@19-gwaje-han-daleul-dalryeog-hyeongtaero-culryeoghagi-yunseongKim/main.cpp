#include <iostream>
#include <iomanip>		//setw()를 사용하기 위한 헤더파일

#define INPUT1 "한 달의 날짜 수를 입력하세요(28, 29, 30, 31): "
#define INPUT2 "첫 날의 요일을 입력하세요(0-6): "
#define OUTPUT "Sun Mon Tue Wed Thr Fri Sat" << endl <<"--- --- --- --- --- --- ---" << endl
#define ERROR1 "28 ~ 31사이의 숫자를 입력해주세요" << endl
#define ERROR2 "0 ~ 6사이의 숫자를 입력해주세요" << endl
using namespace std;

int main () {
	// 한 달에 포함된 날짜 수를 저장할 변수를 생성합니다.
  int lastday;
	// 한 달에 포함된 날짜 수를 입력받습니다.
	// 만일 28 ~ 31사이의 숫자가 아니라면 다시 입력받습니다.
	// 힌트: 무한 반복하다가 조건이 충족되면 빠져나오도록 작성
  cout << INPUT1;
  cin >> lastday;
  
  while(28 > lastday || 31 < lastday){
    cout << ERROR1 << INPUT1;
    cin >> lastday;
  }
  
	// 첫 날의 요일을 저장할 변수를 생성합니다.
  int startday;
	// 첫 날의 요일을 입력받습니다.
	// 0 = 일요일, 1 = 월요일, ..., 6 = 토요일로 처리합니다.
	// 만일 0 ~ 6사이의 숫자가 아니라면 다시 입력받습니다.
	// 힌트: 무한 반복하다가 조건이 충족되면 빠져나오도록 작성
  cout << INPUT2;
  cin >> startday;
  
  while(0 > startday or 6 < startday){
    cout << ERROR2 << INPUT2;
    cin >> startday;
  }

	// 달력의 머릿부분 출력
  cout << OUTPUT;
  
	// 현재까지 출력한 문자의 위치를 저장하기 위한 변수 선언
	// 0으로 초기화 하자

  int space = 0;

  while(space < startday) {
    cout << "    ";
    space++;
  }

	// 첫 날의 요일에 맞춰 공백 출력
	// 힌트: 반복문으로 4칸(글자 3자리+띄어쓰기 1자리)짜리 공백 출력
	// 공백을 출력할 때마다 위치 변수를 하나씩 증가시키자

	for (int i = 1; i < lastday + 1; i++){
      cout<< setw(3) << i << " ";
      space++;
      if(space > 6){
         cout << endl;
         space = 0;
         }
  }

	// 달력의 날짜부분 출력
	// setw(3)을 이용해 3자리 중 오른쪽에 맞춰 출력
	// 다음 날짜 출력 전에 띄어쓰기 1자리 출력
	// 날짜를 출력할 때마다 위치 변수를 하나씩 증가시키자
	// 만일 위치가 6보다 크다면 newline을 출력하고 0으로 초기화 하자

	return 0; 
} 
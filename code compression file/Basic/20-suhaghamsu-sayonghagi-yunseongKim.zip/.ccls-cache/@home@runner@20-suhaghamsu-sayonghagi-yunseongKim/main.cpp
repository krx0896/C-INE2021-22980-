// 입출력을 위한 헤더파일 포함시키기
#include <iostream>
// 수학함수를 사용하기 위한 해더파일 포함시키기
#include <cmath>
// std 네임스페이스 사용 선언
using namespace std;
int main ( ) {

// abs 함수 사용 
    // abs 함수에 인자로 8을 넣어서 출력
    // abs 함수에 인자로 -8을 넣어서 출력
    
   cout << abs(8) << endl;  // absulute value 절댓값
   cout << abs(-8) << endl;

// floor, ceil 함수 사용
    // floor 함수에 인자로 12.78을 넣어서 출력
    // ceil 함수에 인자로 12.78을 넣어서 출력

   cout << floor(12.78) << endl; // 내림
   cout << ceil(12.78) << endl;  // 올림

// log, log10 함수 사용
    // log 함수에 인자로 100을 넣어서 출력
    // log10 함수에 인자로 100을 넣어서 출력

   cout << log(100) << endl; // ln 값
   cout << log10(100) << endl; 
  
// exp, pow 함수 사용
    // exp 함수의 인자로 5를 넣어서 출력
    // pow 함수의 인자로 2와 3을 차례로 넣어서 출력

   cout << exp(5) << endl; // 자연상수 e의 n 제곱값
   cout << pow(2,3) << endl; // (n,k) n의 k제곱

// sqrt 함수 사용
    // sqrt 함수의 인자로 100을 넣어서 출력

   cout << sqrt(100) << endl; // n의 루트값
    return 0; 
}

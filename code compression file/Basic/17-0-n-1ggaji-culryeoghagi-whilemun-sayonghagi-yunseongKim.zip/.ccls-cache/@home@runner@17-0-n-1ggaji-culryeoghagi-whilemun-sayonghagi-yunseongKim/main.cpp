#include <iostream>
#define INPUT "출력할 정수를 입력하세요: "
using namespace std;

int main() {
  int input;
  cout << INPUT;
  cin >> input;
  int counter = 0;

  while(counter < input){

    cout << counter << endl;
    counter++;
  }  

  /* 밑 도 가능
    int counter = -1;

  while(counter < input-1){
    counter++;
    cout << counter << endl;
  
  }  */
  return 0;
}
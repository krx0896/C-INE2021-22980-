#include <iostream>

int main() {
  std::cout << "2018042624 김윤성\n";
} 
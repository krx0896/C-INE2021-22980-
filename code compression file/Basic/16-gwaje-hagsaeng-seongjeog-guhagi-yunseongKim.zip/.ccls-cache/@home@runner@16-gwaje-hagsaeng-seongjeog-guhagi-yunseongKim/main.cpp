#include <iostream>
#define INPUT "세 점수를 차례로 입력하세요: "
#define OUTPUT1 "입력한 점수: "
#define OUTPUT2 "최소 점수와 최대 점수: "
#define OUTPUT3 "학생의 점수: "
using namespace std;


int main () {
	// 입력에 사용할 변수 선언
  int score1, score2, score3;
	// 입력 안내문 출력
  cout << INPUT;
	// 사용자로부터 점수 입력를 입력받음
  cin >> score1 >> score2 >> score3;

	// 최대값을 저장할 변수 선언
	// 3개의 숫자 중 최대 값을 찾아 최대값 변수에 저장
	// 힌트: 두 개씩 비교해봅시다.
  int maxScore;
  if(score1 > score2){
    maxScore = score1;
  }
  else {
    maxScore = score2;
  }
  if(score3 > maxScore){
    maxScore = score3;
  }


	// 최소값을 저장할 변수 선언
	// 3개의 숫자 중 최소 값을 찾아 최소값 변수에 저장
	// 힌트: 두 개씩 비교해봅시다.
  int minScore;
  if(score1 < score2){
    minScore = score1;
  }
  else {
    minScore = score2;
  }
  if(score3 < minScore){
    minScore = score3;
  }

	// 최대값과 최소값의 평균을 계산합니다.
	// 평균은 정수 값이어야하며, 소수점이 발생할 경우 올림으로 처리합니다.
	// 예: 87.5 -> 88로 처리
	// 힌트: 둘을 더한 결과가 홀수일 경우, 2로 나눈 다음 1을 더한다
	// 예를 들어 175인 경우, 2로 나누면 87이고 여기에 1을 더하면 88이 된다.
  int sum = maxScore + minScore;
  
  if(sum % 2 == 1){
    sum++;
  }
  int avg = sum / 2;

	// 계산 결과를 출력합니다.
	// 3개의 점수를 나란히 출력
  cout << OUTPUT1 << score1 << " " << score2 << " " << score3 << endl;
  cout << OUTPUT2 << minScore << " " << maxScore << endl;
  cout << OUTPUT3 << avg;

	return 0; 
} 
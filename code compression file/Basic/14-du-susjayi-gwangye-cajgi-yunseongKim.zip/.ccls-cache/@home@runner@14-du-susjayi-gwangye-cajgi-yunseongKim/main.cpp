#include <iostream>
#define INPUT1 "첫 번재 숫자 입력: "
#define INPUT2 "두 번재 숫자 입력: "
using namespace std;
int main() {
  // num1과 num2를 비교 (num1 >= num2)
  int num1, num2; // 변수선언
  cout << INPUT1;
  cin >> num1;
  cout << INPUT2;
  cin >> num2;
// 1과 2 비교 
  if(num1 >= num2){
   if(num1 > num2){
     cout << num1 << " > " << num2;
   }

   else {
     cout << num1 << " == " << num2 << endl;
   }


  } else {
     cout << num1 << " < " << num2 << endl;

  }
  return 0;
}
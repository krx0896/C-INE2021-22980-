#include <iostream>

int main() {
  std::cout << "제 키는 " << 170 << "cm 입니다." << std::endl;
  std::cout << "이번 학기에는 " << "A" << " 학점을 받을 예정입니다.\n";
  return 0;
} 
#include "main.h"

int main() {
	// 구조체 변수를 선언합니다.	
	Student student; // 구조체, 객체는 대문자, 변수는 소문자
	// cin으로 앞서 선언한 변수의 멤버변수들을 채워줍니다.
  cin >> student.no >> student.name;

	// cout으로 화면에 학번과 이름을 출력합니다.
	// 학번과 이름 사이에는 공백문자가 들어가야 합니다.
	cout << student.no << " " << student.name << endl;
	return 0;
} 
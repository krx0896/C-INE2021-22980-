#include <iostream>
using namespace std;

// 구조체를 정의합니다.
struct Student{
	// string 타입의 학번과 이름 멤버변수를 선언합니다.
  string no;
  string name;
};
#include <iostream>
#include <iomanip>
#define ROWSIZE 5
#define COLSIZE 5
#define INPUT "시작할 숫자를 입력하세요: "
using namespace std;

void reverse(const int origin[][COLSIZE], int result[][COLSIZE], int rowSize, int colSize);
void print(const int arr[][COLSIZE], int rowSize, int colSize);

int main(){
	// 사용자에게 입력 안내 문구를 출력합니다.
  cout << INPUT;
	// 배열의 첫 값을 저장할 변수를 생성하고 사용자로부터 입력받아 저장합니다.
  int num;
  cin >> num;
	// 원본 배열을 생성합니다.
  
	// 2중 반복문을 이용해 사용자가 입력한 값부터 1씩 증가시키며 값을 배열에 저장합니다.
  int origin[ROWSIZE][COLSIZE];
  for(int i=0; i<ROWSIZE; i++){
    for(int j=0; j<COLSIZE; j++){
      origin[i][j] = num;
      num += 1;
    }
  }
	// 결과 배열을 생성합니다.
  
	// reverse 함수를 호출해 원본 배열을 세로로 뒤집은 결과를 결과 배열로 돌려받습니다.
  int result[ROWSIZE][COLSIZE];
  reverse(origin,result,ROWSIZE,COLSIZE);
  print(result,ROWSIZE,COLSIZE);
	// print 함수를 호출해 결과 배열을 출력합니다.

	return 0;
}

void reverse(const int origin[][COLSIZE], int result[][COLSIZE], int rowSize, int colSize){

  for(int i=0; i<rowSize; i++){
    for(int j=0; j<colSize; j++){
      result[i][colSize-j-1] = origin[i][j];
    }
  }
}


void print(const int arr[][COLSIZE], int rowSize, int colSize){
  for(int i=0; i<rowSize; i++){
    for(int j=0; j<colSize; j++){
      cout << setw(2) << arr[i][j] << " ";
    }
    cout << endl;
  }
  cout << endl;
} 
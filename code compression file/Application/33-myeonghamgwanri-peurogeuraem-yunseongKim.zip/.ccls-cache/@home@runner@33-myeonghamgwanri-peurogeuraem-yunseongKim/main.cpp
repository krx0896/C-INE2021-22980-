#include <iostream>
#define MAX 100
#define MENU "1. 입력, 2. 제거, 3. 출력, 4. 종료\n메뉴를 입력하세요: "
#define INPUT_NAME "이름을 입력하세요: "
#define INPUT_TEL "전화번호를 입력하세요: "
#define INPUT_EMAIL "이메일을 입력하세요: "
#define OUTPUT_PRINT1 "번호: "
#define OUTPUT_PRINT2 "이름: "
#define OUTPUT_PRINT3 "전화번호: "
#define OUTPUT_PRINT4 "이메일: "
#define OUTPUT_INSERT1 "추가한 명함의 번호는 "
#define OUTPUT_INSERT2 "입니다."
#define QUERY_DEL_NUM "삭제할 명함의 번호를 입력하세요: "
#define LINE "========== ========== ========== =========="
using namespace std;

struct NameCard{
  string name;
  string tel;
  string email;
};

NameCard insertNameCard(void); // 위쪽에 NameCard 정의후 넣어야함
void removeNameCard(NameCard cards[], int *lastIdx);
void printNameCards(const NameCard cards[], const int lastIdx);

int main(){
  NameCard myCards[MAX];
  //lastIdx는 다음 데이터가 들어갈 0번지 인덱스이다.
  int menu, lastIdx = 0;
    while(1){
    cout << MENU;
    cin >> menu;
    //switch뒤엔 정수만 와야함
    switch(menu){
      case 1:  //입력
      myCards[lastIdx] = insertNameCard();
      cout << OUTPUT_INSERT1 << lastIdx++ << OUTPUT_INSERT2 << endl;
      break;
      case 2: //제거
      removeNameCard(myCards, &lastIdx);
      break;
      case 3:  //출력
      printNameCards(myCards, lastIdx);
      break;
      case 4:  //종료
      return 0;
      break;
      default:
      break;
    }
  }
}

NameCard insertNameCard(void){
  NameCard card;
  
  // 명함의 이름을 입력하라고 물어보고 값을 받아 저장
  cout << INPUT_NAME;
  cin >> card.name;
  // 명함의 전화번호을 입력하라고 물어보고 값을 받아 저장
  cout << INPUT_TEL;
  cin >> card.tel;
  // 명함의 이메일을 입력하라고 물어보고 값을 받아 저장
  cout << INPUT_EMAIL;
  cin >> card.email;

  return card;
} 
void removeNameCard(NameCard cards[], int *lastIdx){
  cout << QUERY_DEL_NUM;
  int idx;
  cin >> idx;
  if(idx >= *lastIdx || idx < 0){
    cout << "잘못된 인덱스를 입력했습니다." << endl;
    return;
  } else {
    for(int i=idx; i < *lastIdx; i++){
      if(i < (*lastIdx)-1)
        cards[i] = cards[i+1];
      else {
        cards[i].name = "";
        cards[i].tel = "";
        cards[i].email = "";
      }
    }
    (*lastIdx)--;
  }
}

void printNameCards(const NameCard cards[], const int lastIdx){
  for(int i =0; i<lastIdx; i++){
    cout << OUTPUT_PRINT1 << i << endl;
    cout << OUTPUT_PRINT2 << cards[i].name << endl;
    cout << OUTPUT_PRINT3 << cards[i].tel << endl;
    cout << OUTPUT_PRINT4 << cards[i].email << endl;
  }
  
}

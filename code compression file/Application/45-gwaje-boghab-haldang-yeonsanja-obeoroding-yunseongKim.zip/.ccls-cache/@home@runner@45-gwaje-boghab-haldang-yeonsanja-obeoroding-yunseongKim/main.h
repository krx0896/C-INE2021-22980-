#include <iostream>
using namespace std;

class Fraction{
	private:
		int numer;	// numerator 분자
		int denom;	// denominator 분모
	public:
		Fraction(): numer(0), denom(0){}
		Fraction(int n, int d):numer(n), denom(d){}
		void setFrac(int n, int d){numer=n; denom=d;}
		void print(){cout << numer << "/" << denom << endl;}
    Fraction& operator+=(Fraction& f);
    Fraction& operator-=(Fraction& f);
    Fraction& operator*=(Fraction& f);
    Fraction& operator/=(Fraction& f);

    int normalize(int n,int d);
};

Fraction& Fraction::operator+=(Fraction& f){
  numer = numer * f.denom + f.numer * denom;
  denom = denom * f.denom;
  normalize(numer,denom);
  return *this;
}

Fraction& Fraction::operator-=(Fraction& f){
  numer = numer * f.denom - f.numer * denom;
  denom = denom * f.denom;
  normalize(numer,denom);
  return *this;
}

Fraction& Fraction::operator*=(Fraction& f){
  numer = numer * f.numer;
  denom = denom * f.denom;
  normalize(numer,denom);
  return *this;
}

Fraction& Fraction::operator/=(Fraction& f){
  numer = numer * f.denom;
  denom = denom * f.numer;
  normalize(numer,denom);
  return *this;
}

int Fraction::normalize(int n, int d){
  numer=n; denom=d;
  int r;
  while (d !=0){
    r = n % d;
    n = d;
    d = r;
  }

  numer = numer / n;
  denom = denom / n;
  return numer and denom;
} 
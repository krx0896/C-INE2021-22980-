#include <iostream>
#include "main.h"
#define QUERY_FRAC "분자와 분모를 입력하세요: "
using namespace std;

int main() {
	int n, d;

	Fraction f[3], g[3];
	string s[] = {"첫 번째 ", "두 번째 ", "세 번째 "};
	for(int i=0; i<3; i++){
		cout << s[i] << QUERY_FRAC;	
		cin >> n >> d;
		f[i].setFrac(n, d);
	}

	Fraction temp = f[0];

	f[0] += f[1];
	f[0].print();
  

	f[0] = temp;
	f[0] -= f[1];
	f[0].print();


	f[0] = temp;
	f[0] *= f[2];
	f[0].print();
	
	f[0] = temp;
	f[0] /= f[2];
	f[0].print();
} 
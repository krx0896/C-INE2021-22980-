#include <iostream>
#include <fstream>

using namespace std;
int main() {
  ifstream input;
  ofstream output;
  
  input.open("inputfile.dat");
  if(!input.is_open()){
    cerr << "input file error" << endl;
    return 1;
  }


  output.open("outputfile.dat");
  if(!output.is_open()){
    cerr << "output file error" << endl;
    return 1;
  }

  char ch;
  while(!input.eof()){
    int a = input.eofbit;
    if(!input.get(ch)) break;
    if(isalpha(ch)){
      ch = toupper(ch);
    }
    output.put(ch);
  }
}

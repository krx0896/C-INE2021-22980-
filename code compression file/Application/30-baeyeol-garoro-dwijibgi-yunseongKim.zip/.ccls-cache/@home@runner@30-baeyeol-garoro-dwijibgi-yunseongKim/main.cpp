#define ROWSIZE 5
#define COLSIZE 5
#include <iostream>
#include <iomanip>
using namespace std;

void foldByRow(const int originalArray[][COLSIZE], int foldedArray[][COLSIZE], int rowSize, int colSize);

void print(const int arr[][COLSIZE], int rowSize, int colSize);

int main() {
  int origin[ROWSIZE][COLSIZE];
  for(int i=0; i<ROWSIZE; i++){
    for(int j=0; j<COLSIZE; j++){
      origin[i][j] = i*5+j;
    }
  }
  int foldedArray[ROWSIZE][COLSIZE];
  foldByRow(origin, foldedArray, ROWSIZE, COLSIZE);
  print(foldedArray, ROWSIZE, COLSIZE);
  return 0;
} 

void foldByRow(const int originalArray[][COLSIZE], int foldedArray[][COLSIZE], int rowSize, int colSize){
  for(int i=0; i<rowSize; i++){
   /* 이거만 쳐주면 foldedArray[rowSize-1] = originalArray[i];  못바꾸는 값이여서 안됨*/
   for(int j=0; j<colSize; j++){
     foldedArray[rowSize-1-i][j] = originalArray[i][j];  
   }
  }
}

void print(const int arr[][COLSIZE], int rowSize, int colSize){
  for(int i=0; i<rowSize; i++){
    for(int j=0; j<colSize; j++){
      cout << setw(2) << arr[i][j] << " ";
    }
    cout << endl;
  }
  cout << endl;
} 
#include "student.h"

Student::Student(){};

Student::Student(int id, const char* name, int age, int gpa): id(id), gpa(gpa), Human(name, age){};

int Student::getId(){
	return id;
}

int Student::getGpa(){
	return gpa;
}
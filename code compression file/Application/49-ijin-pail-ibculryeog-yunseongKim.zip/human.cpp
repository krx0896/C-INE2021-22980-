#include "human.h"
#include <string.h>

Human::Human(){};

Human::Human(const char* name, int age): age(age){
	strcpy(this->name, name);
};

string Human::getName(){
	return name;
}

int Human::getAge(){
	return age;
}
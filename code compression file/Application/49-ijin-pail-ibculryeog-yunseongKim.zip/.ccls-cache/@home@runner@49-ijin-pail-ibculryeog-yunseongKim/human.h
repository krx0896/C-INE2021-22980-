#include <iostream>
using namespace std;

class Human{
protected:
	char name[20];
	int age;
public:
	Human();
	Human(const char* name, int age);
	string getName();
	int getAge();
};

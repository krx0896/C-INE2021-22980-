#include <iostream>
#include <fstream>
#include "student.h"

int main(){

	ofstream output;
	output.open("student.dat");
	if(!output.is_open()){
		cerr << "output file error" << endl;
		return 1;
	}

	Student std[3];
	std[0] = Student(1, "aaa", 30, 100);
	std[1] = Student(2, "bbb", 25, 99);
	std[2] = Student(3, "ccc", 20, 98);

	for(int i=0; i<3; i++){
		output.write((char*)&std[i], sizeof(Student));
	}
	output.close();

	ifstream input;
	input.open("student.dat");
	if(!input.is_open()){
		cerr << "input file error" << endl;
	}

	Student student;
	for(int i=0; i<3; i++){
		input.readsome((char *)&student, sizeof(Student));
		cout << student.getId() << " " << student.getName() << " " << student.getAge() << " " << student.getGpa() << endl;
	}
	input.close();
	return 0;
} 
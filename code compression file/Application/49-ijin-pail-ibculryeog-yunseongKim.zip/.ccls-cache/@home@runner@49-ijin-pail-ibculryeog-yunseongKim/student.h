#include "human.h"

class Student : public Human{
private:
	int id;
	int gpa;
public:
	Student();
	Student(int id, const char* name, int age, int gpa);
	int getId();
	int getGpa();
};
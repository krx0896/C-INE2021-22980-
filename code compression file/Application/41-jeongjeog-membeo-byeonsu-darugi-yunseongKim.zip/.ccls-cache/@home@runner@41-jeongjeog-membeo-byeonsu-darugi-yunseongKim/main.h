class Account {
	private:
		static int cnt;
		int num;
	public:
		Account();
		void setAccount(int num);
		static int getCnt(){			
			return Account :: cnt;
		}	
};

int Account :: cnt = 0;

Account :: Account(){
	Account::cnt++;
}

void Account :: setAccount(int num){
	this->num = num;
}
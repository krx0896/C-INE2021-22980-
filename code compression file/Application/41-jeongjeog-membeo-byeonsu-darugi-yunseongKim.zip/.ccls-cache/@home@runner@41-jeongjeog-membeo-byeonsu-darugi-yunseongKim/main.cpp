#include <iostream>
#include "main.h"
#define PRINT_ACC " 번 계좌 계설 완료"
#define PRINT_ERR "더 이상 계좌를 계설할 수 없습니다."
using namespace std;

int main() {

  for(int i=0; i<4; i++){
    Account acc;
    if(acc.getCnt() > 3){
      cout << PRINT_ERR << endl;
    } else {
      cout << i << PRINT_ACC << endl;
    }
  }
} 
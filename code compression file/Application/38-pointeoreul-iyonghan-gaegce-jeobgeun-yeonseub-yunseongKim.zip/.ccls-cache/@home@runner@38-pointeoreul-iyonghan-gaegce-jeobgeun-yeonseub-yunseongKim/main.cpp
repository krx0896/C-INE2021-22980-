#include "main.h"
#define QUERY_RADIUS "반지름을 입력하세요: "
#define PRINT_AREA "너비: "
#define PRINT_PERIMETER ", 둘레: "
using namespace std;


int main() {
  cout << "첫 번째 " << QUERY_RADIUS;
  int r1, r2;
  cin >> r1;
  cout << "두 번째 " << QUERY_RADIUS;
  cin >> r2;

  Circle c1(r1), c2(r2), *pC;
  pC = &c1; // c1의 주소
  cout << PRINT_AREA << (*pC).getArea();
  cout << PRINT_PERIMETER << (*pC).getPerimeter() << endl;

  pC =&c2;
  cout << PRINT_AREA << pC->getArea();
  cout << PRINT_PERIMETER << pC->getPerimeter() << endl;

} 

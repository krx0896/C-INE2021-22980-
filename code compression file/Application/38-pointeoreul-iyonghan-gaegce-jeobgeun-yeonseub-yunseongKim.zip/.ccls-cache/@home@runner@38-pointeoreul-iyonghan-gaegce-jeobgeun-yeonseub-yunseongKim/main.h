#include <iostream>
using namespace std;

class Circle{
	private:
		double radius;
	public:
		Circle(double radius);
		Circle();
		void setRadius(double radius);
		double getRadius() const;
		double getArea() const;
		double getPerimeter() const;
};

Circle :: Circle(double radius) : radius(radius){}
Circle :: Circle() : radius(0.0){}

void Circle :: setRadius(double radius){
	this->radius = radius;
}

double Circle :: getRadius() const{
	return this->radius;
}

double Circle :: getArea() const{
	const double PI = 3.14;
	return (PI*radius*radius);
}

double Circle :: getPerimeter() const{
	const double PI = 3.14;
	return (2*PI*radius);
}
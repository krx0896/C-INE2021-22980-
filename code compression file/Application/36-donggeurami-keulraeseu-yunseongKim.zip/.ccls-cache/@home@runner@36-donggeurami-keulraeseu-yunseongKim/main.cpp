#include <iostream>
using namespace std;

class Circle{
  int r;
  const double PI = 3.14;
  public:
  Circle();
  Circle(int r1);
  ~Circle();
  int getRadius() const;
  void setRadius(int r1);
  double getArea() const;
  double getPerimeter() const;
};

Circle::Circle(){
  r = 0;
}

Circle::Circle(int r1){
  r =r1;
}

Circle::~Circle(){
  cout << "My radius is" << r << "Bye" << endl;
}

void Circle::setRadius(int r1){
  r = r1;
}

int Circle::getRadius() const{
  return r;
}

double Circle::getArea() const{
  return r*r*PI;
}

double Circle::getPerimeter() const{
  return 2*r*PI;
}

int main() {
  Circle c1 = Circle();
  c1.setRadius(5);
  cout << c1.getArea() << endl;
  cout << c1.getPerimeter() << endl;
  Circle c2 = Circle(3);
  cout << c2.getArea() << endl;
}

#include <iostream>
#include "main.h"
#define QUERY_POS "x좌표와 y좌표를 입력해주세요: "
using namespace std;

int main() {
	cout << QUERY_POS;
	int x, y;
	cin >> x >> y;

	Point a, b, c, d, e;
	a.setPoint(x, y);
	
	b = +a;
	b.print();

	c = -a;
	c.print();

	d = a+b;
	d.print();

	e = c-d;
	e.print();
} 
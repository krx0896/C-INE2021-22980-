#include <iostream>
using namespace std;

class Point{
	private:
		int x, y;
	public:
		Point(): x(0), y(0){}
		Point(int x, int y): x(x), y(y){}
		void setPoint(int x, int y){this->x=x; this->y=y;}
		void print(){cout << "(" << x << ", " << y << ")" << endl;}
    Point operator+();
    friend Point operator-(Point p); // 외부함수로 +와 다른방식으로 만들어줌 같은방식도 가능  
    Point operator+(Point p);
    friend Point operator-(Point p1, Point p2);
};

Point Point::operator+(){
  return Point(this->x, this->y);
}

Point operator-(Point p){
  return Point(-p.x, -p.y);
}

Point Point::operator+(Point p){
  return Point(x+p.x, y+p.y);
}

Point operator-(Point p1, Point p2){
  return Point(p1.x-p2.x, p1.y-p2.y);
}
#include <iostream>
#include <fstream>

using namespace std;
int main() {
  ifstream input;
  input.open("integerfile.dat");
  if(!input.is_open()){
    cerr << "input file error" << endl;
    return 1;
  }

  ofstream output;
  output.open("result.dat");
  if(!output.is_open()){
    cerr << "output file error" << endl;
    return 1;
  }

  int num;
  bool is_first = true;
  while(!input.eof()){
    if(is_first) {
      is_first = false;
    } else {
      output << " ";
    }
    input >> num;
    output << num*num;
  }

  input.close();
  output.close();

  return 0;
}

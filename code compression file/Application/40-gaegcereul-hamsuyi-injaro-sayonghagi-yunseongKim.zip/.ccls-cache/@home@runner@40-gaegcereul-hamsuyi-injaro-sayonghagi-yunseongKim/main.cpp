#include "main.h"
#define QUERY_RADIUS "반지름을 입력하세요: "
#define PRINT_AREA "너비: "
#define PRINT_PERIMETER ", 둘레: "

void printCircleValue(Circle c);
void printCircleAddr(Circle *c);
void printCircleRef(Circle &c);

int main() {
  cout << QUERY_RADIUS;
  int r;
  cin >> r;
  Circle a; 
  a.setRadius(r);

  printCircleValue(a);
  printCircleAddr(&a);
  printCircleRef(a);
}

void printCircleValue(Circle b){
  cout << PRINT_AREA << b.getArea();
  cout << PRINT_PERIMETER << b.getPerimeter() << endl;
}

void printCircleAddr(Circle *c){
  cout << PRINT_AREA << (*c).getArea();
  cout << PRINT_PERIMETER << c->getPerimeter() << endl;
}

void printCircleRef(Circle &d){
  cout << PRINT_AREA << d.getArea();
  cout << PRINT_PERIMETER << d.getPerimeter() << endl;
}
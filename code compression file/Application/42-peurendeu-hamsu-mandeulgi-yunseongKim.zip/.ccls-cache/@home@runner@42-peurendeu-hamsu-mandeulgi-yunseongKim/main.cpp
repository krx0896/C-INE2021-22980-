#include <iostream>
#include "main.h"
#define QUERY_INPUT_RECT "사각형의 너비와 높이를 입력하세요: "
#define QUERY_INPUT_CIRCLE "반지름을 입력하세요: "
using namespace std;

int main() {
	int w, h;
	string s[] = {"첫 번째 ", "두 번째 "};
	Rect r[2];
	for(int i=0; i<2; i++){
		cout << s[i] << QUERY_INPUT_RECT;
		cin >> w >> h;
		r[i].setRect(w, h);
	}	
	cout << QUERY_INPUT_CIRCLE;
	int rad;
	cin >> rad;
	Circle c(rad);

	RectManager manager; //r은 private 함수기 때문에 이런식으로 접근해줘야함
	cout << area(r[0]) << endl;
	cout << boolalpha << manager.equals(&r[0], &r[1]) << endl;
	cout << boolalpha << c.largerThanRect(r[0]) << endl;
	cout << boolalpha << c.largerThanRect(r[1]) << endl;
} 
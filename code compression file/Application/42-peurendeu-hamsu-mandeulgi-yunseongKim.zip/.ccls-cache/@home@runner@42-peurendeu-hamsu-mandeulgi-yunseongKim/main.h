// forward declarations
class Rect;
class Circle;
class RectManager{
	public:
		bool equals(Rect *r, Rect *s);
};

class Rect{
	private:
		int width, height;
		int getLargerOne(){return width>height?width:height;}
	public:
		Rect():width(0), height(0){}; //아무것도 안들어왔을때 0 
		Rect(int w, int h):width(w), height(h){};		// 들어왔을때 설정
		void setRect(int w, int h){this->width=w; this->height=h;};
    friend int area(Rect r);
    friend bool RectManager::equals(Rect *r,Rect *s);
    friend Circle; // Circle의 모든 함수 접근 가능 
}; // 값 설정

class Circle{
	private:
		int radius;
	public:
		Circle(int r):radius(r){};		
		bool largerThanRect(Rect r);		
};

int area(Rect r){
	return r.width*r.height;
}

bool RectManager::equals(Rect *r, Rect *s){
	return r->width==s->width && r->height==s->height;
}

bool Circle::largerThanRect(Rect r){
	return radius > r.getLargerOne();
}
#include <iostream>

using namespace std;

class Student {
    double kor, eng, mat;
  public:
    Student(double kor, double eng, double mat);
    double getTot() const;
    double getAvg() const;
    void setScores(double kor, double eng, double mat);
};

Student::Student(double kor, double eng, double mat):kor(kor),eng(eng),mat(mat){}

void Student::setScores(double kor, double eng, double mat){
  this->kor = kor;
  this->eng = eng;
  this->mat = mat;
}

double Student::getTot() const{
  return (kor+eng+mat);
}

double Student::getAvg() const{
  return((kor+eng+mat)/3);
}
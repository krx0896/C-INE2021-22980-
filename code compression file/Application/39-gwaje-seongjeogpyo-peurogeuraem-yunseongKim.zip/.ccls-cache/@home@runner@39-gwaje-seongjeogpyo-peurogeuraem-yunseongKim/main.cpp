#include <iostream>
#include "main.h"
#define MAX 3
#define QUERY_SCORE "국영수 성적을 차례로 입력하세요: "
using namespace std;

int main()
{
  int kor[3], eng[3], mat[3];
    cout << "첫 번째 " << QUERY_SCORE;
    cin >> kor[0] >> eng[0] >> mat[0];
    cout << "두 번째 " << QUERY_SCORE;
    cin >> kor[1] >> eng[1] >> mat[1];
    cout << "세 번째 " << QUERY_SCORE;
    cin >> kor[2] >> eng[2] >> mat[2];

    Student s0(kor[0], eng[0], mat[0]), *pS0;
    s0.setScores(kor[0], eng[0], mat[0]);
    pS0 = &s0;
    cout <<(*pS0).getTot() << ", ";
    cout << (*pS0).getAvg() << endl;

    Student s1(kor[1], eng[1], mat[1]), *pS1;
    s1.setScores(kor[1], eng[1], mat[1]);
    pS1 = &s1;
    cout << (*pS1).getTot() << ", ";
    cout << (*pS1).getAvg() << endl;

    Student s2(kor[2], eng[2], mat[2]), *pS2;
    s2.setScores(kor[2], eng[2], mat[2]);
    pS2 = &s2;
    cout << (*pS2).getTot() << ", ";
    cout << (*pS2).getAvg() << endl;
  
} 

/*
int main() {
  
  for(int i=0; i<MAX; i++){
    int kor[i], eng[i], mat[i];
    cout << "첫 번째 " << QUERY_SCORE;
    cin >> kor[i] >> eng[i] >> mat[i];
    cout << "두 번째 " << QUERY_SCORE;
    cin >> kor[i+1] >> eng[i+1] >> mat[i+1];
    cout << "세 번째 " << QUERY_SCORE;
    cin >> kor[i+2] >> eng[i+2] >> mat[i+2];
    
    Student c0(kor[i], eng[i], mat[i]), *pC0;
    c0.setScores(kor[i],eng[i],mat[i]);
    pC0 = &c0;
    cout << (*pC0).getTot() << ", ";
    cout << (*pC0).getAvg() << endl;

    Student c1(kor[i+1], eng[i+1], mat[i+1]), *pC1;
    c1.setScores(kor[i+1],eng[i+1],mat[i+1]);
    pC1 = &c1;
    cout << (*pC1).getTot() << ", ";
    cout << (*pC1).getAvg() << endl;

    Student c2(kor[i+2], eng[i+2], mat[i+2]), *pC2;
    c2.setScores(kor[i+2],eng[i+2],mat[i+2]);
    pC2 = &c2;
    cout << (*pC2).getTot() << ", ";
    cout << (*pC2).getAvg() << endl;

  }
} */
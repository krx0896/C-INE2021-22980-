#include <iostream>
#define MAX 3

// 메뉴를 출력하기 위해 필요한 문자열
#define QUERY_MENU "1. 대여, 2. 반납, 3. 추가, 4. 삭제, 5. 목록, 6. 종료\n번호를 입력하세요: " 
#define ERR_MENU_RANGE "해당 번호는  사용할 수 없습니다."

// 도서 대여 시 필요한 문자열
#define QUERY_RENT_NUM "대여하려는 도서 번호를 입력하세요: "
#define ERR_RENT_RANGE "대여할 수 있는 도서의 범위를 넘어갔습니다."
#define ERR_RENT_ALREADY "해당 도서는 이미 대여됐습니다."

// 도서 반납 시 필요한 문자열
#define QUERY_RETURN_NUM "반납하려는 도서 번호를 입력하세요: "
#define ERR_RETURN_RANGE "반납할 수 있는 도서의 범위를 넘어갔습니다."
#define ERR_RETURN_NOT_YET "대여하지 않은 도서는 반납할 수 없습니다."

// 도서 추가 시 필요한 문자열
#define QUERY_NAME "책 이름을 입력하세요: "
#define QUERY_AUTHOR "저자 이름을 입력하세요: "
#define ERR_NOT_ENOUGH "더 이상 도서를 추가할 수 없습니다."

// 도서 삭제 시 필요한 문자열
#define QUERY_DEL_NUM "삭제하려는 도서 번호를 입력하세요: "
#define ERR_DEL_RANGE "삭제할 수 있는 도서의 범위를 넘어갔습니다."
#define ERR_DEL_RENTED "대여된 도서는 삭제할 수 없습니다."

// 도서목록 출력 시 필요한 문자열
#define PRINT_LINE "=============================="
#define PRINT_NUM "번호: "
#define PRINT_NAME "이름: "
#define PRINT_AUTHOR "저자: "
#define PRINT_RENT "대여: "

using namespace std;

// 1. 도서 정보를 저장할 구조체를 생성합니다.
struct Book{
  string name;
  string num;
  string author;
  bool rent;
};
/*
 * 함수 원형 예시 - 다르게 작성할 경우 제거해도 무방합니다.
 *
 * 2. 입력 오류 처리를 위한 함수
 * int findError(Book books[], const int lastIdx, const int num);
 *
 * 3. 도서 구조체를 삭제하기 위한 함수
 * void removeOneByOne(Book books[], int *lastIdx, const int num);
 *
 * 4. 도서 대여를 처리하기 위한 함수
 * void rentBook(Book books[], const int lastIdx);
 *
 * 5. 도서 반납을 처리하기 위한 함수
 * void returnBook(Book books[], const int lastIdx);
 *
 * 6. 도서를 삭제하기 위한 함수
 * void delBook(Book books[], int *lastIdx);
 *
 * 7. 도서를 추가하기 위한 함수
 * void addBook(Book books[], int *lastIdx);
 *
 * 8. 도서 목록을 출력하기 위한 함수
 * void printBooks(const Book books[], const int lastIdx);
 */

 int findError(Book books[], const int lastIdx, const int num);
 void removeOneByOne(Book books[], int *lastIdx, const int num);
 void rentBook(Book books[], const int lastIdx);
 void returnBook(Book books[], const int lastIdx);
 void delBook(Book books[], int *lastIdx);
 void addBook(Book books[], int *lastIdx);
 void printBooks(const Book books[], const int lastIdx);

int main() {
	// 도서 구조체 배열을 생성합니다.	
  Book books[MAX];
	// 사용자 입력을 저장할 변수, 도서의 수를 관리할 변수를 선언합니다.
  int menu, lastIdx =0;
	// 무한 반복하며 사용자의 입력에 따라 정해진 함수를 호출합니다.
    while(1){
    cout << QUERY_MENU;
    cin >> menu;
    switch(menu){
      case 1:// 대여
      rentBook(books, lastIdx);
      break;
      case 2:// 반납
      returnBook(books, lastIdx);
      break;
      case 3:// 추가
      addBook(books, &lastIdx);
      break;
      case 4:// 삭제
      delBook(books , &lastIdx);
      break;
      case 5:// 목록
      printBooks(books, lastIdx);
      break;
      case 6:// 종료
      return 0;
      break;
      default:
      cout << ERR_MENU_RANGE << endl; 
      break;
    }
  }
} 
		// 메뉴를 출력하고 입력을 받습니다.
		// 입력에 따라 정해진 함수를 호출합니다.

int findError(Book books[], const int lastIdx, const int num){
   if(num < 0 || num > lastIdx-1){
      return 1;
   }
   if(books[num].rent == 1){
      return 2;
   }
   if(books[num].rent == 0){
      return 3;
   }
  return 0;
}

void removeOneByOne(Book books[], int *lastIdx, const int num){
   for(int i=num;i < (*lastIdx)-1;i++){
      if(i == (*lastIdx)-1){
         books[i].name = "";
         books[i].author = "";
         books[i].rent = false;
      }
        books[i].name=books[i+1].name;
        books[i].author=books[i+1].author;
   }
   (*lastIdx)--;
}
void rentBook(Book books[], const int lastIdx){
   cout << QUERY_RENT_NUM;
   int num;
   cin >> num;
   findError(books,lastIdx,num);
   if(findError(books,lastIdx,num) == 1){
      cout << ERR_RENT_RANGE;
   }
   else if(findError(books,lastIdx,num) == 2){
      cout << ERR_RENT_ALREADY;
   }
   else{
      books[num].rent = true;
   }
}
void returnBook(Book books[], const int lastIdx){
   cout << QUERY_RETURN_NUM;
   int num;
   cin >> num;
   findError(books,lastIdx,num);
   if(findError(books,lastIdx,num) == 1){
      cout << ERR_RETURN_RANGE;
   }
   else if(findError(books,lastIdx,num) == 2){
      books[num].rent = false;
   }
   else{
      cout << ERR_RETURN_NOT_YET;
   }
}
void delBook(Book books[], int *lastIdx){
   cout << QUERY_DEL_NUM;
   int num;
   cin >> num;
   findError(books, *lastIdx, num);
   if(findError(books,*lastIdx,num) == 1){
      cout << ERR_DEL_RANGE;
   }
   else if(findError(books,*lastIdx,num) == 2){
      cout << ERR_DEL_RENTED;
   }
   else{
      removeOneByOne(books, lastIdx , num);
   }
}
void addBook(Book books[], int *lastIdx){
   if(*lastIdx >= MAX){
      cout << ERR_NOT_ENOUGH;
   }
   else{
      cout << QUERY_NAME;
      cin >> books[*lastIdx].name;
      cout << QUERY_AUTHOR;
      cin >> books[*lastIdx].author;
      books[*lastIdx].name=books[*lastIdx].name;
      books[*lastIdx].author=books[*lastIdx].author;
      (*lastIdx)++;
   }   
}

void printBooks(const Book books[], const int lastIdx){
   for(int i=0; i < lastIdx;i++){
   cout << PRINT_LINE << endl << PRINT_NUM << i << endl;
   cout << PRINT_NAME << books[i].name << endl;
   cout << PRINT_AUTHOR << books[i].author << endl;
   if(books[i].rent == 1){
      cout << "대여 중" << endl; 
   }
   else if(books[i].rent == 0){
      cout << "대여 가능" << endl;
   }
   cout << PRINT_LINE;
   }
}
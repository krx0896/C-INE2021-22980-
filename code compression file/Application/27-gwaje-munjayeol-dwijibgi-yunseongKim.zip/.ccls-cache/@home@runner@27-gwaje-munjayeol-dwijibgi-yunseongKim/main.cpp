#include <iostream>
#include <string>
#define INPUT "문자열을 입력하세요: "
using namespace std;

int main() {
	// 사용자에게 입력 안내 문구를 출력합니다.
  cout << INPUT;
	// string 타입의 문자열 변수를 생성합니다.
  string a;
	// cin을 이용해 사용자로부터 입력을 받습니다.
  cin >> a;
	// 문자열의 크기를 저장하기 위한 변수를 생성합니다.
	// 문자열의 크기를 구한 후, 앞서 생성한 변수에 저장합니다.
  int asize = a.size();
  
	// 반복문을 이용해 사용자가 입력한 문자열을 뒤에서부터 한글자씩 출력합니다.
  for(int i=asize-1; i>=0; i--){
    cout << a[i]; 
  }
	// endl을 출력합니다.
  cout << endl;
	return 0;
} 
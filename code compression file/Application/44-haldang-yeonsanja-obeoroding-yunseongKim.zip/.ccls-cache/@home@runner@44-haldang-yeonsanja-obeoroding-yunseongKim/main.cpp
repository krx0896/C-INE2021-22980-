#include <iostream>
#include "main.h"
#define QUERY_FRAC "분자와 분모를 입력하세요: "
using namespace std;

int main() {
	cout << QUERY_FRAC;
	int n, d;
	cin >> n >> d;
	Fraction f, g(n, d);
	f = g;
	f.print();
} 
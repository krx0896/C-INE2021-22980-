#include <iostream>
using namespace std;

class Fraction{
	private:
		int numer;	// numerator 분자
		int denom;	// denominator 분모
	public:
		Fraction(): numer(0), denom(0){}
		Fraction(int n, int d):numer(n), denom(d){}
		void setFrac(int n, int d){numer=n; denom=d;}
		void print(){cout << numer << "/" << denom << endl;}
    Fraction& operator=(Fraction& f);
};

Fraction& Fraction::operator=(Fraction& f){
  numer = f.numer;
  denom = f.denom;
  return *this;
}
#include <iostream>
using namespace std;
// 속성값 계좌번호, 밸런스, 총 출력함수 4가지
class Account
{
  int account_number;
  int balance;

public:
  Account(int account_number, int balance);
  void print();
  void deposit(int money);
  void withdraw(int money);
  void transfer(Account &acc, int money);
};
// this->: private 함수에 있는 걸 바로 박아줌
Account::Account(int account_number, int balance)
{
 this->account_number = account_number;
  this->balance = balance;
}

/* 클래스의 멤버 함수를 정의해 주세요 */
void Account::print()
{
  cout << "==========" << endl;
  cout << "계좌 번호: " << account_number;
  cout << "\t잔금: " << balance << endl;
  cout << "==========" << endl;
}

void Account::deposit(int money)
{
  balance = balance + money;
}

void Account::withdraw(int money)
{
  balance = balance - money;
}

void Account::transfer(Account &other, int money)
{
    other.balance += money; // 밸런스 맴버함수를 쓰겠다
    this->balance -= money;
  }


int takeInput(string msg)
{
  cout << msg;
  int money;
  cin >> money;
  return money;
}

int main()
{
  Account acc1 = Account(1, 0);
  Account acc2 = Account(2, 0);
  Account *acc = &acc1;
  Account *other = &acc2;

  int current = 0;
  int menu;
  while (1)
  {
    cout << "현재 계좌 번호는 " << current + 1 << " 입니다." << endl;
    cout << "수행할 동작을 입력하세요 (1. 입금, 2. 출금, 3. 송금, 4. 계좌 전환, 5. 종료): ";
    cin >> menu;
    if (menu == 1)
    {
      acc->deposit(takeInput("입금할 금액을 입력해 주세요: "));
    }
    else if (menu == 2)
    {
      acc->withdraw(takeInput("출금할 금액을 입력해 주세요: "));
    }
    else if (menu == 3)
    {
      acc->transfer(*other, takeInput("송금할 금액을 입력해 주세요: "));
    }
    else if (menu == 4)
    {
      if (!current)
      {
        acc = &acc2;
        other = &acc1;
      }
      else
      {
        acc = &acc1;
        other = &acc2;
      }
      current = !current;
    }
    else
    {
      return 0;
    }

    acc1.print();
    acc2.print();
  }
}  
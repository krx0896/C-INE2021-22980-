#define INPUT "5개의 숫자를 입력하세요: "
#include <iostream>
using namespace std;

void reverse(const int origin[], int modified[], int size);
void print(const int arr[], int size);

int main() {
  cout << INPUT;
  const int CAPACITY = 5;
  int numbers[CAPACITY];
  for(int i=0; i<CAPACITY; i++){
    cin >> numbers[i];
  }

  int result[CAPACITY];
  reverse(numbers, result, CAPACITY);

  print(numbers, CAPACITY);
  print(result, CAPACITY);
  return 0;
} 

void reverse(const int origin[], int modified[], int size){
  for(int i=0; i<size; i++){
    modified[size-(i+1)] = origin[i];
  }
}

void print(const int arr[], int size){
  for(int i=0; i<size; i++){
    cout << arr[i] << " ";
  }
  cout << endl;
} 
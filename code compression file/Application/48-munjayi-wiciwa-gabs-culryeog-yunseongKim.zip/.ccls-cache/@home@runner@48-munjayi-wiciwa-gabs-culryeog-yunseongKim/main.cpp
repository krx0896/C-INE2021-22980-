#include <iostream>
#include <fstream>

using namespace std;
int main() {
  
  ifstream input;
  input.open("hello.dat");
  if(!input.is_open()){
    cerr << "input file error" << endl;
    return 1;
  }

  int pos;
  char ch;
  while(1){
    pos = input.tellg();
    if(!input.get(ch)) break;
    cout << pos << " " << ch <<endl;
  }
}

#include <iostream>
#include <string>
#define INPUT "점수를 다섯 개 입력하세요: "
using namespace std;

// 함수를 수행하면 점수 배열에 따라 학점 배열이 채워집니다.
void cal(const int score[], char grade[], int size);
// 함수를 수행하면 화면에 점수와 학점이 나란히 출력됩니다.
void print(const int score[], const char grade[], int size);

int main() {
	// 입력 안내 문구를 출력합니다.
  cout << INPUT;
	// 점수를 저장할 정수 배열을 생성합니다.
  const int CAPACITY = 5;
  int Score[CAPACITY];
	// 사용자로부터 점수를 입력 받습니다.
  for(int i=0; i<CAPACITY; i++){
    cin >> Score[i];
  }
	// 학점을 저장할 문자 배열을 생성합니다.
  char str[CAPACITY];

  cal(Score, str, CAPACITY);
  print(Score, str, CAPACITY);


	return 0;
} 

	// cal 함수의 인자로 점수 배열, 학점 배열, 배열 크기를 전달합니다.
  void cal(const int score[], char grade[], int size){
    for(int i=0; i<size; i++){
    if(score[i] >= 90 && score[i] <=100){
      grade[i] = 'A';
    } else if(score[i]>=80 && score[i]<90){
      grade[i] = 'B';
    } else if(score[i]>=70 && score[i]<80){
      grade[i] = 'C';
    } else if(score[i]>=60 && score[i]<70){
      grade[i] = 'D';
    } else {
      grade[i] = 'F';
    }
  }

  }
	// print 함수의 인자로 점수 배열, 학점 배열, 배열 크기를 전달합니다.
  void print(const int score[], const char grade[], int size){
    for(int i=0; i<size; i++){
      cout << score[i] << " " << grade[i] << endl;
    }
  }  
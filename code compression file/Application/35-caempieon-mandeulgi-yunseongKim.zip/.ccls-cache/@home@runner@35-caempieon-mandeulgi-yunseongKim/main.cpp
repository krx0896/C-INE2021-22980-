#include <iostream> // 이후 생략
using namespace std; // 이후 생략

//---------------------------------------------
enum Position {TOP, JUNGLE, MID, BOTTOM, SUPPORT};
struct Properties{
  int hp;
  int pPower; // 물리 공격력
  int mPower; // 마법 공격력    int pDef; // 물리 방어력
  int mDef; // 마법 방어력
  double atkSpd; // 공격 속도
  int skilSpd; // 스킬 가속도
  int critRate; // 치명타 확률
  int moveSpd; // 이동 속도
};

class Champion {
  string name;
  Position position;
  Properties prop;
  public:
  Champion(string name1, Position position1, Properties prop1);
  void printChampion() const;
};

Champion::Champion(string name1, Position position1, Properties prop1){
  name = name1;
  position = position1;
  prop = prop1;
}

string printPos(Position p){
  if(p == TOP) return "TOP";
  else if(p == JUNGLE) return "JUNGLE";
  else if(p == MID) return "MID";
  else if(p == BOTTOM) return "BOTTOM";
  else return "SUPPORT";
}

void Champion::printChampion() const{
  cout << "이름: " << name << endl;
  cout << "포지션: " << printPos(position) << endl;
  cout << "체력: " << prop.hp << endl;
  cout << "물리 공격력: " << prop.pPower << endl;
}



int main(int argc, char** argv) {
  Properties prop_garen = {620, 77, 0, 42, 32, 625, 0, 0};
  Champion garen = Champion("Garen", TOP, prop_garen);
  Properties prop_lux = {600, 20, 30, 50, 32, 625, 0, 0};
  Champion lux = Champion("Lux", MID, prop_lux);

  garen.printChampion();
  cout << endl;
  lux.printChampion();
}
#include <iostream>

using namespace std;

class CTime{
  int h;
  int m;
  int s;
  public:
   void setElapsed(int s);
   void printTime();
};

void CTime::setElapsed(int s){
  this-> m = s/60;
  this-> h = m/60;
  this-> s = s%60;
  this-> m = m%60;
}

void CTime::printTime(){
  cout << h << "시간 " << m << "분 "<< s << "초";
}

int main() {
  cout << "자정부터 지나간 초를 입력하세요: ";
  int Elapsed;
  cin >> Elapsed;

  CTime t;
  t.setElapsed(Elapsed);
  t.printTime();

  return 0;
} 
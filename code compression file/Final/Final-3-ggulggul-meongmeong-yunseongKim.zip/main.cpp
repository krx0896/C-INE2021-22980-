#include <iostream>

class CAnimal{
public:
	virtual char* getSound() = 0;
};

class CPig{
  public:
  void printSound(char p1);
};
class CDog{
    void printSound(char p2);
};

  void printSound(char p1){
  }

int main() {
  CPig *p1 = new CPig;
  printSound(p1);
  CDog *p2 = new CDog;
  printSound(p2);
} 
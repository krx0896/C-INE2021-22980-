# 기말고사 3. 꿀꿀 멍멍

  ** 이 프로그램이 다음과 같은 결과를 출력하도록 클래스 CPig, CDog, 함수 printSound를 작성하시오.**

  ![result](./assets/fimg3.PNG)

  ## steps
  1. CPig 클래스와 CDog 클래스를 각각 작성합니다.
  2. printSound 함수를 작성합니다.
  3. CPig와 CDog의 인스턴스를 만들고 printSound 함수의 인자로 전달합니다.
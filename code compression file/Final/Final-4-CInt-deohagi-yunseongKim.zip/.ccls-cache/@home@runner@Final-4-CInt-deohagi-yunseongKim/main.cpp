#include <iostream>

using namespace std;

class CInt {
};


int main() {
	CInt i1 = 1;
	CInt i2 = i1 + 1;
	CInt i3 = i1 + i2;

	cout << i1.m_value << endl;
	cout << i2.m_value << endl;
	cout << i3.m_value << endl;
	cout << (++i3).m_value << endl;
	cout << (i3++).m_value << endl;
	cout << i3.m_value << endl;
} 
#include <iostream>
#include <iomanip>
#define HEADER setw(5) << "Name" << setw(10) << "Height(m)" << setw(10) << "Weight(T)" << setw(12) << "horse-power" << endl;
#define LINE "=====================================" << endl;
using namespace std;


struct Robot{
  string name;
  int m;
  int T;
  int h;
};

void printRobot(Robot *r);
void printAvg(Robot r[], int size);

int main(){
  int size = 0;

  cout << HEADER;

  Robot aaa = {"AAA", 18, 80, 3000};
  Robot bbb = {"BBB", 17, 70, 2500};
  Robot ccc = {"CCC", 20, 90, 3500};
  Robot ddd = {"DDD", 22, 100, 5000};


  for(int i=0; i<size; i++){

    Robot r[i] = aaa;
        Robot r[i] = bbb;
            Robot r[i] = ccc;
                Robot r[i] = ddd;
  }
  Robot r;
  r.printRobot(Robot aaa);
  r.printAvg(Robot r[], int size);

}

void printRobot(Robot *r){
  cout << endl << LINE;
  cout << endl;
  cout << setw(5) << r[1].name << setw(10) << r[1].m << setw(10) << r[1].T << setw(12) << r[1].h << endl;
  cout << setw(5) << r[2].name << setw(10) << r[2].m << setw(10) << r[2].T << setw(12) << r[2].h << endl;
  cout << setw(5) << r[3].name << setw(10) << r[3].m << setw(10) << r[3].T << setw(12) << r[3].h << endl;
  cout << setw(5) << r[4].name << setw(10) << r[4].m << setw(10) << r[4].T << setw(12) << r[4].h << endl;
  cout << LINE;
  cout << endl << setw(5) << r[5].name << setw(10) << r[5].m << setw(10) << r[5].T << setw(12) << r[5].h << endl;
}

void printAvg(Robot r[], int size){
  r[5].m = (r[1].m+r[2].m+r[3].m+r[4].m)/4;
  r[5].T = (r[1].T+r[2].T+r[3].T+r[4].T)/4;
  r[5].h = (r[1].h+r[2].h+r[3].h+r[4].h)/4;
}